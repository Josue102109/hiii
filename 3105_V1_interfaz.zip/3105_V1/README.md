# 3105 V1 — interfaz SwiftUI

Interfaz inicial para iPhone hecha con SwiftUI.

## Abrir
1. En un Mac, abre `3105V1.xcodeproj` con Xcode.
2. Selecciona un simulador o conecta tu iPhone.
3. Ejecuta el proyecto con **Run**.

## Clave de demostración
La clave local de prueba es `123`.

**Importante:** esta clave está escrita dentro de la app y no protege una versión distribuida. Para una activación real, valida las claves desde un servidor. No uses esta demo como sistema de seguridad.

## Marca
El símbolo de ondas es un diseño original inspirado en audio. No es el logotipo oficial de Spotify ni una aplicación afiliada a Spotify.
