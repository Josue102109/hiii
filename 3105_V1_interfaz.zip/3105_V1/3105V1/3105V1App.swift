import SwiftUI

@main
struct _3105V1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
