import SwiftUI

struct ContentView: View {
    @State private var productKey = ""
    @State private var activated = false
    @State private var showError = false

    private let demoKey = "123"

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.035, green: 0.07, blue: 0.06), .black, .black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                // 3105 branding — original audio-inspired mark, not the Spotify logo.
                ZStack {
                    Circle()
                        .fill(Color.green)
                        .frame(width: 112, height: 112)
                    Image(systemName: "waveform")
                        .font(.system(size: 54, weight: .bold))
                        .foregroundStyle(.black)
                }

                Text("3105")
                    .font(.system(size: 42, weight: .black, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(.white)
                    .padding(.top, 14)

                Text("V1  •  PRODUCT ACTIVATION")
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(.white.opacity(0.48))
                    .padding(.top, 7)

                Spacer()

                VStack(alignment: .leading, spacing: 18) {
                    Text("INGRESE SU CLAVE DE PRODUCTO")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, alignment: .center)

                    SecureField("Escriba su KEY", text: $productKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.asciiCapable)
                        .padding(.horizontal, 16)
                        .frame(height: 54)
                        .background(Color.white.opacity(0.07))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay {
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.green.opacity(0.8), lineWidth: 1)
                        }
                        .foregroundStyle(.white)

                    Button(action: activate) {
                        Text(activated ? "CLAVE ACTIVADA" : "ACTIVAR CLAVE")
                            .font(.system(size: 15, weight: .heavy, design: .rounded))
                            .tracking(0.6)
                            .foregroundStyle(.black)
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(Color.green)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }

                    Button {
                        productKey = ""
                        showError = false
                        activated = false
                    } label: {
                        Text("CANCELAR")
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.7))
                            .frame(maxWidth: .infinity)
                    }

                    if showError {
                        Text("CLAVE INCORRECTA. INTÉNTELO DE NUEVO.")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(.red)
                            .frame(maxWidth: .infinity)
                    }

                    if activated {
                        Text("Acceso de demostración concedido.")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(.green)
                            .frame(maxWidth: .infinity)
                    }
                }
                .padding(22)
                .background(.ultraThinMaterial.opacity(0.55))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .overlay {
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.green.opacity(0.35), lineWidth: 1)
                }

                Spacer()

                Text("3105 V1  •  VERSION 1.0")
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .tracking(1.5)
                    .foregroundStyle(.white.opacity(0.35))
                    .padding(.bottom, 18)
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 16)
        }
        .preferredColorScheme(.dark)
    }

    private func activate() {
        if productKey == demoKey {
            activated = true
            showError = false
        } else {
            activated = false
            showError = true
        }
    }
}

#Preview {
    ContentView()
}
